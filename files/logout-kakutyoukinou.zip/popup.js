document.addEventListener('DOMContentLoaded', loadList);

document.getElementById('saveBtn').addEventListener('click', saveSite);
document.getElementById('urlInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveSite();
});

function saveSite() {
  const urlInput = document.getElementById('urlInput');
  let url = urlInput.value.trim();

  if (!url) {
    alert('URLを入力してください');
    return;
  }

  if (!/^https?:\/\//i.test(url)) {
    url = 'https://' + url;
  }

  // 最初はスイッチON（true）の状態で追加します
  chrome.storage.local.get({ sites: [] }, (result) => {
    const currentSites = result.sites;
    currentSites.push({ id: Date.now(), url: url, enabled: true });

    chrome.storage.local.set({ sites: currentSites }, () => {
      urlInput.value = '';
      loadList();
    });
  });
}

function loadList() {
  const listDiv = document.getElementById('bookmarkList');
  listDiv.innerHTML = '';

  chrome.storage.local.get({ sites: [] }, (result) => {
    if (result.sites.length === 0) {
      listDiv.innerHTML = '<span style="color:#999; font-size:12px;">登録されたサイトはありません</span>';
      // リストが空ならルールも全クリア
      applyNetworkRules([]);
      return;
    }

    result.sites.forEach((site) => {
      const item = document.createElement('div');
      item.className = 'site-item';

      // 1. URLテキスト
      const urlSpan = document.createElement('span');
      urlSpan.className = 'site-url';
      urlSpan.textContent = site.url;

      // 操作パーツをまとめるコンテナ
      const actionContainer = document.createElement('div');
      actionContainer.className = 'action-container';

      // 2. ON/OFFスイッチ
      const switchLabel = document.createElement('label');
      switchLabel.className = 'switch';
      
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = site.enabled;
      
      const slider = document.createElement('span');
      slider.className = 'slider';

      switchLabel.appendChild(checkbox);
      switchLabel.appendChild(slider);

      // 画面を開いた時の勝手なアニメーションを防ぐ遅延処理
      setTimeout(() => {
        switchLabel.classList.add('switch-animated');
      }, 100);

      // スイッチが切り替わったときの処理
      checkbox.addEventListener('change', (e) => {
        site.enabled = e.target.checked;
        chrome.storage.local.set({ sites: result.sites }, () => {
          applyNetworkRules(result.sites);
        });
      });

      // 3. 削除ボタン
      const delBtn = document.createElement('button');
      delBtn.className = 'delete-btn';
      delBtn.textContent = '削除';
      delBtn.addEventListener('click', () => deleteSite(site.id));

      actionContainer.appendChild(switchLabel);
      actionContainer.appendChild(delBtn);
      
      item.appendChild(urlSpan);
      item.appendChild(actionContainer);
      listDiv.appendChild(item);
    });

    // 画面を開いた時にも最新のルールをブラウザに適用
    applyNetworkRules(result.sites);
  });
}

function deleteSite(id) {
  chrome.storage.local.get({ sites: [] }, (result) => {
    const filtered = result.sites.filter(site => site.id !== id);
    chrome.storage.local.set({ sites: filtered }, loadList);
  });
}

// ★最重要：スイッチがONになっているドメインの通信だけクッキーを削ぎ落とすルールをブラウザに適用する関数
function applyNetworkRules(sites) {
  chrome.declarativeNetRequest.getSessionRules((oldRules) => {
    const oldIds = oldRules.map(rule => rule.id);

    // スイッチが「ON」になっているサイトだけを絞り込む
    const enabledSites = sites.filter(site => site.enabled);

    if (enabledSites.length === 0) {
      // ONのサイトがなければルールをすべて削除して終了
      chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: oldIds }, () => {});
      return;
    }

    // ONになっているサイトのドメインを元に、通信ブロックルールを組み立てる
    const newRules = enabledSites.map((site, index) => {
      try {
        const urlObj = new URL(site.url);
        const domain = urlObj.hostname; // 例: www.canva.com や canva.com

        return {
          id: index + 1,
          priority: 1,
          action: {
            type: "modifyHeaders",
            requestHeaders: [{ "header": "Cookie", "operation": "remove" }],
            responseHeaders: [{ "header": "Set-Cookie", "operation": "remove" }]
          },
          condition: {
            // このドメインが含まれるすべての通信を対象にする
            "urlFilter": domain,
            // main_frame(タブ全体) も sub_frame(iframe) もすべてクッキーを遮断
            "resourceTypes": ["main_frame", "sub_frame", "stylesheet", "script", "image", "xmlhttprequest"]
          }
        };
      } catch (e) {
        return null;
      }
    }).filter(rule => rule !== null);

    // 新しいルールセットを一括適用
    chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: oldIds,
      addRules: newRules
    }, () => {});
  });
}

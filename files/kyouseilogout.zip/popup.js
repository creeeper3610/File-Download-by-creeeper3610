document.addEventListener('DOMContentLoaded', loadList);

document.getElementById('saveBtn').addEventListener('click', saveSite);
document.getElementById('urlInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveSite();
});

function saveSite() {
  const nameInput = document.getElementById('siteName');
  const urlInput = document.getElementById('urlInput');
  
  let name = nameInput.value.trim();
  let url = urlInput.value.trim();

  if (!name || !url) {
    alert('名前とURLの両方を入力してください');
    return;
  }

  if (!/^https?:\/\//i.test(url)) {
    url = 'https://' + url;
  }

  chrome.storage.local.get({ sites: [] }, (result) => {
    const currentSites = result.sites;
    currentSites.push({ id: Date.now(), name: name, url: url });

    chrome.storage.local.set({ sites: currentSites }, () => {
      nameInput.value = '';
      urlInput.value = '';
      loadList();
    });
  });
}

function loadList() {
  const listDiv = document.getElementById('bookmarkList');
  listDiv.innerHTML = '';

  chrome.storage.local.get({ sites: [] }, (result) => {
    if (result.sites.length === 0) {
      listDiv.innerHTML = '<span style="color:#999; font-size:12px;">登録されたサイトはありません</span>';
      return;
    }

    result.sites.forEach((site) => {
      const item = document.createElement('div');
      item.className = 'site-item';

      const nameSpan = document.createElement('span');
      nameSpan.className = 'site-name';
      nameSpan.textContent = site.name;

      const actionContainer = document.createElement('div');
      actionContainer.className = 'action-container';

      const openBtn = document.createElement('button');
      openBtn.className = 'list-btn open-btn';
      openBtn.textContent = '開く';
      
      // クッキーなしの目印をつけて通常のタブで開く
      openBtn.addEventListener('click', () => {
        let finalUrl = site.url;
        // URLにすでに「?」が含まれているかで結合文字を変える
        if (finalUrl.includes('?')) {
          finalUrl += '&nc=1';
        } else {
          finalUrl += '?nc=1';
        }
        chrome.tabs.create({ url: finalUrl });
      });

      const delBtn = document.createElement('button');
      delBtn.className = 'list-btn delete-btn';
      delBtn.textContent = '削除';
      delBtn.addEventListener('click', () => deleteSite(site.id));

      actionContainer.appendChild(openBtn);
      actionContainer.appendChild(delBtn);
      
      item.appendChild(nameSpan);
      item.appendChild(actionContainer);
      
      listDiv.appendChild(item);
    });
  });
}

function deleteSite(id) {
  chrome.storage.local.get({ sites: [] }, (result) => {
    const filtered = result.sites.filter(site => site.id !== id);
    chrome.storage.local.set({ sites: filtered }, loadList);
  });
}
